<link rel="stylesheet" type="text/css" href="tugas3.css">
<h1>SELAMAT DATANG PELANGGAN</h1>
<h1><?php echo $_SESSION['pelanggan']['nama_plg']; ?></h1>
<div align="left">
<p>1. <button>list tas custom</button>, tambahkan pesananmu terlebih dahulu.</p>
<p>2. <button>pesanan</button>, melihat pesanan yang sudah ditambahkan. Anda boleh membatalkan 
	<br> pesanan dengan mengklik aksi <i>hapus</i>.</p>
<p>3. <button>checkout</button>, ini tahap terakhir untuk mengakhiri pesanan dengan mengecek jumlah, 
	<br> warna, dan detail lain serta mengisi data untuk pengiriman.</p>
<p>4. ketika muncul untuk cetak hasil pesanan, maka cetak. Refrech halaman dengan tab <button>checkout</button> 
	sekali lagi, untuk cetak halaman tersebut. <br> karena halaman pesanan ini hanya muncul sekali setelah login.</p>	
<p>7. <button>logout</button>, menu keluar dari halaman.</p>
</div>