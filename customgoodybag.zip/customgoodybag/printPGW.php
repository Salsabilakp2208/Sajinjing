<?php
	include "koneksi.php";
?>
<html>
<head>
	<title>DATA PEGAWAI</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
	<center>
	<table width="100% auto">
		<tr>
			<th colspan="8">DATA PEGAWAI</th>
		</tr>
		<tr height="40">
			<th>NO</th>
			<th>ID PEGAWAI</th>
			<th>PASSWORD</th>
			<th>NAMA PEGAWAI</th>
			<th>&emsp;JK&emsp;</th>
			<th>ALAMAT</th>
			<th>NO TELP/WA</th>
			<th>AKSI</th>
		</tr>
		
				<?php $no=1;?>
				<?php 
				$sql = "SELECT *FROM pegawai ";
				$query = mysqli_query($conn, $sql);
				while($data=mysqli_fetch_array($query)): ?>
				<tr>
					<td><center><?php echo $no++;?></center></td>
					<td><center><?php echo $data['kode_pgw'];?></center></td>
					<td><center><?php echo $data['password'];?></center></td>
					<td><center><?php echo $data['nama_pgw'];?></center></td>
					<td><center><?php echo $data['jenis_kelamin'];?></center></td>
					<td><center><?php echo $data['alamat'];?></center></td>
					<td><center><?php echo $data['no_telp'];?></center></td>
					<td align="center">
						<a href="?page=editPGW&id=<?php echo $data['kode_pgw'];?>"><button> EDIT</button></a>
						<a href="hapusPGW.php?id=<?php echo $data['kode_pgw'];?>"><button>DELETE</button></a>
					</td>	
				</tr>
				<?php endwhile; ?>
	</table>
	<script>
		window.print();
	</script>
	</center>

</body>
</html>

