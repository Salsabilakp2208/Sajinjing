<?php
	session_start();
	$kode_brg = $_GET['id'];
	unset($_SESSION['keranjang'][$kode_brg]);

	echo "<script>alert('produk telah di hapus keranjang belanja');</script>";	
	echo "<script>location='http://localhost/customgoodybag/portalPLG.php?page=pesan';</script>";	
?>