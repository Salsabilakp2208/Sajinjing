<?php
		include "koneksi.php";
		$kode_pgw=$_GET['id'];
		$query="SELECT *FROM pegawai WHERE kode_pgw='$kode_pgw'";
		$cek=mysqli_query($conn, $query);
		$no=1;
		while($data=mysqli_fetch_array($cek)){
			$jenis_kelamin=$data['jenis_kelamin'];
?>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="">
</head>
<body>
	<div align="center">

	<h3>EDIT DATA PEGAWAI</h3>
		<form method="POST">
			<input type="hidden" value="<?php echo $data['kode_pgw'];?>" name="kode_pgw">
			<table width="40% auto" border="0" >
				<tr height="50">
					<th colspan="5">DATA PEGAWAI</th>
				</tr>
				<tr height="46">
					<td>PASSWORD</td>
					<td align="left"><input type="text" name="password" size="10" maxlength="6" value="<?php echo $data['password'];?>"></td>	

				</tr>
				<tr height="46">
					<td>NAMA PEGAWAI</td>
					<td align="left"><input type="text" name="nama_pgw" size="15" maxlength="20" value="<?php echo $data['nama_pgw'];?>"></td>	
		
				</tr>
				<tr height="46">
					<td>JENIS KELAMIN</td>
					<td align="left">
						<input type="radio" name="jenis_kelamin" value="L">
						<? if($jenis_kelamin=='Laki-laki'){echo 'checked;'}?>Laki-laki

						<input type="radio" name="jenis_kelamin" value="P">
						<? if($jenis_kelamin=='Perempuan'){echo 'checked;'}?>Perempuan
					</td>
				</tr>
				<tr height="46">
					<td>ALAMAT</td>
					<td align="left"><input type="text" name="alamat" size="30" value="<?php echo $data['alamat'];?>"></td>	

				</tr>
				<tr height="46">
					<td>NO TELP/WA</td>
					<td align="left"><input type="text" name="no_telp" size="20" value="<?php echo $data['no_telp'];?>"></td>	
				</tr>
			<?php } ?>
			</table>
			<br>
			<button name="simpan">SIMPAN</button>
		</form>

		<?php
			if(isset($_POST['simpan']))
			{
				$kode_pgw=$_POST['kode_pgw'];
				$password=$_POST['password'];
				$nama_pgw=$_POST['nama_pgw'];
				$jenis_kelamin=$_POST['jenis_kelamin'];
				$alamat=$_POST['alamat'];
				$no_telp=$_POST['no_telp'];

				$query="UPDATE pegawai SET password='$password', nama_pgw='$nama_pgw', jenis_kelamin='$jenis_kelamin', alamat='$alamat' , no_telp='$no_telp' WHERE kode_pgw='$kode_pgw'";
				mysqli_query($conn,$query);
				echo "<script>alert('data berhasil di update');</script>";
				header("location:http://localhost/customgoodybag/portalPGW.php?page=pegawai");
			}
		?>
</div>
</body>
</html>