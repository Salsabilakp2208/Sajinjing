<?php
	session_start();
	include "koneksi.php";

	if(!isset($_SESSION['pelanggan']) OR empty($_SESSION['pelanggan']))
	{
		echo "<script>alert('silahkan login');</script>";
		echo "<script>location='login2.php';<script>";
		exit();
	}
?>


<html>
<head>
	<title>PEMBAYARAN</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
	<h4>KONFIRMASI PEMBAYARAN</h4>
	<form method="POST" enctype="multipart/form-data">
		<p align="left">Kirim bukti pembayaran Anda disini</p>
		<table>
			<tr>
				<td>KODE BARANG</td>
				<td><input type="text" name="kode_brg"></td>
			</tr>
			<tr>
				<td>KODE PEGAWAI</td>
				<td><input type="text" name="kode_pgw"></td>
			</tr>
			<tr>
				<td>JUMLAH</td>
				<td><input type="number" name="tarif" min="1"></td>
			</tr>
			<tr>
				<td>FOTO BUKTI</td>
				<td><input type="file" name="bayar"><br>foto bukti harus JPG max. 2 MB</td>
			</tr>
		</table>
		<button name="kirim">KIRIM</button>
	</form>

	<?php
		//jk ada tombol kirim
		if(isset($_POST['kirim']))
		{
			//upload dulu foto bukti
			$namabukti = $_FILES['bayar']['name'];
			$lokasibukti = $_FILES['bayar']['tmp_name'];
			$bayar = date("YmdHis").$namabukti;
			move_uploaded_file($lokasibukti, "buktipembayaran/$bayar");

			$kode_plg = $_POST['kode_plg'];
			$kode_brg = $_POST['kode_brg'];
			$kode_pgw = $_POST['kode_pgw'];
			$tarif = $_POST['tarif'];

			//simpan pembayaran
			$conn->query("INSERT INTO custom(kode_brg,kode_pgw,tarif,bayar) VALUES ('$kode_brg','$kode_pgw','$tarif','$bayar')");
		
			echo "<script>alert('terimakasih sudah mengirim bukti pembayaran');</script>";
			echo "<script>location='?page=nota';<script>";	
		}
	?>
</body>
</html>