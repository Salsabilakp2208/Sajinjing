<html>
<head>
	<title>HASIL PENCARIAN</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<html>
<head>
	<title>DATA PESANAN</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
		<form method="POST" action="?page=cariCS">
			<input type="text" name="search" placeholder="Value To Search">
			<input type="submit" name="submit" value="FILTER">
			<br><br>
		</form>

	<center>
	<table width="100% auto">
		<tr>
			<th colspan="8">DATA PESANAN</th>
		</tr>
		<tr height="40">
			<th>NO</th>
			<th>KODE CUSTOM</th>
			<th>KODE BARANG</th>
			<th>KODE PEGAWAI</th>
			<th>TARIF</th>
			<th>BUKTI BAYAR</th>
			<th>AKSI</th>
		</tr>
		
				<?php $no=1;?>
				<?php 
				include "koneksi.php";
				$query = mysqli_query($conn, "SELECT *FROM custom WHERE custom LIKE '%$cari%' ");
				while($data=mysqli_fetch_array($query)): ?>
				<tr>
					<td><center><?php echo $no++;?></center></td>
					<td><center><?php echo $data['kode_custom'];?></center></td>
					<td><center><?php echo $data['kode_brg'];?></center></td>
					<td><center><?php echo $data['kode_pgw'];?></center></td>
					<td><center><?php echo $data['tarif'];?></center></td>
					<td><center><?php echo $data['bayar'];?></center></td>
					<td align="center">
						<a href="hapusCS.php?id=<?php echo $data['kode_custom'];?>"><button>REMOVE</button></a>
					</td>	
				</tr>
				<?php endwhile; ?>
	</table>
	<br><br><br>
	<a href="portalPGW.php?page=pegawai"><button>KEMBALI KE PENCARIAN</button></a>
	</center>
</body>
</html>