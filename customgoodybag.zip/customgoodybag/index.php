<html>
<head>
	<title>SABIL CUSTOM GOODY BAG</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
	<div class="index">
		<img src="ka.png" class="avatar">
			<a href="login.php" class="button1">PEGAWAI</a>
			<br><br><br><br><br><br>
			<a href="login2.php" class="button2">PELANGGAN</a>
	</div>
</body>
</html>
