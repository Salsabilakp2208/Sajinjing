<?php
include "koneksi.php";
?>
<html>
<head>
	<title>DATA PELANGGAN</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body width="90% auto">
	<center>
	<table width="100% auto">
		<tr>
			<th colspan="8">DATA PELANGGAN</th>
		</tr>
		<tr height="40">
			<th>NO</th>
			<th>ID PELANGGAN</th>
			<th>PASSWORD</th>
			<th>NAMA PELANGGAN</th>
			<th>&emsp;JK&emsp;</th>
			<th>ALAMAT</th>
			<th>NO TELP/WA</th>
			<th>AKSI</th>
		</tr>
				
				<?php $no=1;?>
				<?php 
				$sql = "SELECT *FROM pelanggan ";
				$query = mysqli_query($conn, $sql);
				while($d=mysqli_fetch_array($query)):?>
				<tr>
					<td><center><?php echo $no++;?></center></td>
					<td><center><?php echo $d['kode_plg'];?></center></td>
					<td><center><?php echo $d['password'];?></center></td>
					<td><center><?php echo $d['nama_plg'];?></center></td>
					<td><center><?php echo $d['jenis_kelamin'];?></center></td>
					<td><center><?php echo $d['alamat'];?></center></td>
					<td><center><?php echo $d['no_telp'];?></center></td>
					<td align="center">
						<a href="?page=editPLG&id=<?php echo $d['kode_plg'];?>"><button> EDIT</button></a>
						<a href="hapusPLG.php?id=<?php echo $d['kode_plg'];?>"><button>DELETE</button></a>
					</td>
				</tr>
				<?php endwhile;?>
	</table>
	<script>
		window.print();
	</script>
	</center>
</body>
</html>