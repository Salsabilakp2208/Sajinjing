<html>
<head>
	<title>DATA BARANG</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
	
<div align="center">
    <h3>DAFTAR BARANG</h3>
		<table width="80% auto" >
			<tr height="60" align="center" bgcolor="#f5f5f5">
				<td>KODE</td>
				<td>JENIS GD</td>
				<td>NAMA GD</td>
				<td>DESC</td>
				<td>WARNA</td>
				<td>HARGA</td>
				<td>ADD TO CART</td>
			</tr>

	<?php
		include "koneksi.php";
		$ambil = $conn->query("SELECT *FROM barang");

		while($row = $ambil->fetch_assoc()){
		$kode_brg	= $row['kode_brg'];
		$jenis_brg 	= $row['jenis_brg'];
		$nama 		= $row['nama'];
		$ukuran 	= $row['ukuran'];
		$warna 		= $row['warna'];
		$harga 		= $row['harga'];
	?>
			<tr align="center">
				<td><input type="hidden" name="kode_brg"><?php echo $kode_brg;?></td>
				<td><input type="hidden" name="jenis_brg"><?php echo $jenis_brg; ?></td>
				<td><input type="hidden" name="nama"><?php echo $nama; ?></td>
				<td><input type="hidden" name="ukuran"><?php echo $ukuran; ?></td>
				<td><input type="hidden" name="warna"><?php echo $warna;?></td>
				<td><input type="hidden" name="harga"> Rp. <?php echo number_format($harga); ?></td>
				<td>
					<a href="proses_add.php?id=<?php echo $kode_brg; ?>"><input type="submit" name="add" value="ADD"></a>
					<a href="?page=detail&id=<?php echo $kode_brg; ?>"><input type="submit" name="detail" value="DETAIL"></a>
				</td>
			</tr>
	
	<?php		
		}
	?>

		</table>
	</div>
	<br><br>
</body>
</html>