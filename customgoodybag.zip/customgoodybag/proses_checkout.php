<?php
	$kode_brg = $_SESSION['keranjang']['kode_brg'];
	$kode_plg = $_SESSION['pelanggan']['kode_plg'];
	$kode_pgw = $_SESSION['pegawai']['kode_pgw'];
	$tgl_pesan = date("Y-m-d");

	$kode_pesan = $conn->insert_id;
				
	$conn->query("INSERT INTO pesanan(kode_plg,kode_brg,tgl_pesan) VALUES('$kode_plg','$kode_brg','$tgl_pesan')");				
	//mengkosongkan keranjang
	unset($_SESSION['keranjang']);

	//tampilan dialihkan ke halaman nota, nota dari pembelian yang barusan
	echo "<script>alert('pesanan sukses');</script>";
	echo "<script>location='?page=riwayat';</script>";
?>