<?php
	include "koneksi.php";
?>
<html>
<head>
	<title>LAMAN DATA PEGAWAI</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
	<div class="register">
		<img src="person.png" class="avatar">
		<h1>Silahkan isi data diri Anda</h1><br>
			<form method="post">
				<table border="0">
					<tr>
						<td class="td">ID </td>
						<td><input type="text" name="kode_pgw" maxlength="20" size="20" value="<?= autonumber("pegawai", "kode_pgw", "2", "PGW") ?>"></td>
					</tr>
					<tr>
						<td class="td">PASSWORD</td>
						<td><input type="text" name="password" maxlength="20" size="20"></td>
					</tr>
					<tr>
						<td class="td">NAMA</td>
						<td><input type="text" name="nama_pgw" maxlength="20" size="20"></td>
					</tr>
					<tr>
						<td class="td">JENIS KELAMIN&emsp;&emsp;</td>
						<td><input type="radio" name="jenis_kelamin" value="Laki-laki">Laki-laki
							<input type="radio" name="jenis_kelamin" value="Perempuan">Perempuan
						</td>
					</tr>
					<tr>
						<td class="td">ALAMAT</td>
						<td><input type="text" name="alamat" cols="50" rows="4"><br></td>
					</tr>
					<tr>
						<td class="td">NO HP/WA</td>
						<td><input type="text" name="no_telp" maxlength="20" size="20"><br></td>
					</tr>
				</table>
				<br>
				<input type="submit" name="simpan" value="simpan" class="btn-login">
				<a href="index.php"><input type="button" name="tampil" value="kembali" class="btn-login"></a>
			</form>
	</div>
	<?php
	error_reporting(0);
	include "koneksi.php";

	function autonumber($tabel, $kolom, $lebar=0, $awalan=''){
   
	    $host = "localhost";
	    $usr = "root";
	    $pwd = "";
	    $dbname = "customgoodybag";
	    $conn = mysqli_connect($host, $usr, $pwd, $dbname);
	    
	    if(mysqli_connect_error()){
	        echo 'database gagal dikoneksikan!'.mysqli_connect_error();
	    }
		    //proses auto number
		    $auto = mysqli_query($conn, "select $kolom from $tabel order by $kolom desc limit 6") or die(mysqli_error());
		    $jumlah_record = mysqli_num_rows($auto);
		    if($jumlah_record == 0)
		    $nomor = 1;  
	    else{
	        $row = mysqli_fetch_array($auto);
	        $nomor = intval(substr($row[0], strlen($awalan)))+1;
	    }


	    if($lebar>0)
	        $angka = $awalan.str_pad ($nomor, $lebar, "0", STR_PAD_LEFT);
	    else
	        $angka=$awalan.$nomor;
	    return $angka;
		}


	$kode_pgw=$_POST['kode_pgw'];
	$password=$_POST['password'];
	$nama_pgw=$_POST['nama_pgw'];
	$jenis_kelamin=$_POST['jenis_kelamin'];
	$alamat=$_POST['alamat'];
	$no_telp=$_POST['no_telp'];
	
	if(isset($_POST['simpan'])){
		$query=mysqli_query($conn,"insert into pegawai values('$kode_pgw','$password','$nama_pgw','$jenis_kelamin','$alamat','$no_telp')") 
			or die(mysqli_error());
		if($query){
			echo "Berhasil input data ke database";
		}else{
			echo "Gagal tersimpan";
		}
	}
?>
</body>
</html>
