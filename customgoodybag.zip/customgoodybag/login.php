<?php
	session_start();
	include "koneksi.php";
?>

<html>
<head>
	<title>Login ADMIN</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
	<div class="container">
		<img src="person.png" class="avatar">
		<h1>Login Here</h1>
		<form method="POST" action="login.php">	
			<p>Username</p>
			<input type="text" placeholder="Enter your Username" name="username" >
			<p>Password</p>
			<input type="password" placeholder="Enter Your Password" name="password" >
			<input type="submit" name="login" value="LOGIN" class="btn-login">
			<a href="pegawai.php">Do you have an account?</a><br><br>
			<a href="index.php">Go back!</a>		
		</form>
		<?php
			if(isset($_POST['login'])){
			$ambil = $conn->query("SELECT *FROM pegawai WHERE kode_pgw='$_POST[username]' AND  password= '$_POST[password]' ");
			$yangcocok = $ambil->num_rows;
				if($yangcocok == 1)
				{
					$_SESSION['pegawai'] = $ambil->fetch_assoc();
					echo "<script>alert('Login Sukses!');</script>";
					echo "<script>location='http://localhost/customgoodybag/portalPGW.php?page=beranda';</script>";	
				}
				else
				{
					echo "<script>alert('Login Gagal!');</script>";
					echo "<script>location='http://localhost/customgoodybag/login.php';</script>";	
				}
			}
		?>
	</div>
</body>
</html>