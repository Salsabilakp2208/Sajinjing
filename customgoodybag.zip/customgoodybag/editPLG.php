<?php
		include "koneksi.php";
		$kode_plg=$_GET['id'];
		$query="SELECT *FROM pelanggan WHERE kode_plg='$kode_plg'";
		$cek=mysqli_query($conn, $query);
		$no=1;
		while($data=mysqli_fetch_array($cek)){
			$jenis_kelamin=$data['jenis_kelamin'];
?>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
	<div align="center">
	<h3>EDIT DATA PELANGGAN</h3>
		<form method="POST">
			<input type="hidden" value="<?php echo $data['kode_plg'];?>" name="id_plg">
			<table width="40% auto" border="0" >
				<tr height="50">
					<th colspan="5">DATA PELANGGAN</th>
				</tr>
				<tr height="46">
					<td>PASSWORD</td>
					<td align="left"><input type="text" name="password" size="10" maxlength="6" value="<?php echo $data['password'];?>"></td>	

				</tr>
				<tr height="46">
					<td>NAMA PEGAWAI</td>
					<td align="left"><input type="text" name="nama_plg" size="15" maxlength="20" value="<?php echo $data['nama_plg'];?>"></td>	
		
				</tr>
				<tr height="46">
					<td>JENIS KELAMIN</td>
					<td align="left">
						<input type="radio" name="jenis_kelamin" value="L">
						<? if($jenis_kelamin=='Laki-laki'){echo 'checked;'}?>Laki-laki

						<input type="radio" name="jenis_kelamin" value="P">
						<? if($jenis_kelamin=='Perempuan'){echo 'checked;'}?>Perempuan

					</td>

				</tr>
				<tr height="46">
					<td>ALAMAT</td>
					<td align="left"><input type="text" name="alamat" size="30" value="<?php echo $data['alamat'];?>"></td>	

				</tr>
				<tr height="46">
					<td>NO TELP/WA</td>
					<td align="left"><input type="text" name="no_telp" size="20" value="<?php echo $data['no_telp'];?>"></td>	
				</tr>
			<?php } ?>
			</table>
			<br>
			<button name="simpan">SIMPAN</button>
		</form>

		<?php
			if(isset($_POST['simpan']))
			{
				$id_pgw=$_POST['kode_plg'];
				$password=$_POST['password'];
				$nama_pgw=$_POST['nama_plg'];
				$jenis_kelamin=$_POST['jenis_kelamin'];
				$alamat=$_POST['alamat'];
				$no_telp=$_POST['no_telp'];

				$query="UPDATE pelanggan SET password='$password', nama_plg='$nama_plg', jenis_kelamin='$jenis_kelamin', 
					alamat='$alamat' , no_telp='$no_telp' WHERE kode_plg='$kode_plg'";

				mysqli_query($conn,$query);
				echo "<script>alert('data berhasil di update');</script>";
				header("location:http://localhost/customgoodybag/portalPGW.php?page=pelanggan");
			}
		?>
	</div>
</body>
</html>