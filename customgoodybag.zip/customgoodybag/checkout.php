<?php
	$conn = new mysqli("localhost","root","","customgoodybag");

	if(!isset($_SESSION['pelanggan']))
	{
		echo "<script>alert('silahkan login');</script>";
		echo "<script>location='cek_login.php';<script>";
	}

	if(empty($_SESSION['keranjang']) OR !isset($_SESSION['keranjang']))
	{
		echo "<script>alert('keranjang kosong, silahkan pilih tas custom Anda');</script>";	
		echo "<script>location='http://localhost/customgoodybag/portalPLG.php?page=custom';</script>";	
	}
?>

<html>
<head>
	<title>Checkout</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
	<div align="center">

		<table width="100% auto">
			<tr height="80" align="center" bgcolor="#4CAF50" >
				<th>NO</th>
				<th>ID</th>
				<th>JENIS GD</th>
				<th>NAMA GD</th>
				<th>DESC</th>
				<th>WARNA</th>
				<th>HARGA</th>
				<th>QTY</th>
				<th>SUBHARGA</th>
			</tr>

			<?php $no=1;?>
			<?php $totalbelanja = 0; ?>
			<?php $ongkir = 30000; ?>
			<?php foreach ($_SESSION['keranjang'] as $kode_brg => $jumlah) : ?>
			<?php
				$ambil = $conn->query("SELECT *FROM barang WHERE kode_brg='$kode_brg' ");	
				$pecah = $ambil ->fetch_assoc();
				$subharga = $pecah['harga']*$jumlah;
				//echo "<pre>";
				//print_r($_SESSION);
				//echo "</pre>";
			?>
			<tr align="center">
				<td><?php echo $no; ?></td>
				<td><?php echo $pecah['kode_brg']; ?></td>
				<td><?php echo $pecah['jenis_brg']; ?></td>
				<td><?php echo $pecah['nama']; ?></td>
				<td><?php echo $pecah['ukuran']; ?></td>
				<td><?php echo $pecah['warna']; ?></td>
				<td>Rp. <?php echo number_format($pecah['harga']); ?></td>
				<td><?php echo $jumlah; ?></td>
				<td>Rp. <?php echo number_format($subharga); ?></td>
			</tr>
			<?php $no++;?>
			<?php $totalbelanja += $subharga; ?>
			<?php $Total=$totalbelanja+$ongkir; ?>
			<?php endforeach ?>
			<tr>
				<th colspan="8">Total Belanja</th>
				<th align="left">&emsp;Rp. <?php echo number_format($Total) ?></th>
			</tr>
		</table>
		<br>
		<p>
			Silahkan melakukan pembayaran Rp. <?php echo number_format($Total); ?> ke <br>
			<strong>BANK MANDIRI 137-001088-3276 AN. SALSABILA KAMELIYA PUTRI KODE PEGAWAI : PGW01</strong>
			<br>SETELAH TRANSFER, MOHON KIRIM HASIL CETAK HALAMAN INI DI HALAMAN NOTA. SERTAKAN TTD ANDA.
			<br>Terimakasih.
		</p>
		<p>
			Total belanja sudah termasuk ongkir seluruh daerah yaitu Rp. 30,000
		</p>
		<form method="POST">
			<table width="20% auto">
			<th>

				<label>KODE BARANG</label>
				<div>
					<input type="radio" name="kode[]" value="1">1
					<input type="radio" name="kode[]" value="2">2
					<input type="radio" name="kode[]" value="3">3
					<input type="radio" name="kode[]" value="4">4
					<input type="radio" name="kode[]" value="5">5
					<input type="radio" name="kode[]" value="6">6
				</div>
				<label>NAMA PELANGGAN</label>
				<input type="text" readonly value="<?php echo $_SESSION['pelanggan']['nama_plg'];?>"><br><br>
				<label>NO HP/WA</label>
				<input type="text" readonly value="<?php echo $_SESSION['pelanggan']['no_telp'];?>"><br><br>
				<label>Alamat lengkap pengiriman</label><br>
				<textarea cols="40" rows="2" name="alamat_pengiriman"><?php echo $_SESSION['pelanggan']['alamat'];?></textarea>
				<br>
			</th>
			<td><button name="checkout"><b>CHECKOUT</b></button></td>
			<td><h6><i>*lakukan checkout sesuai jumlah kode yang dipesan</i></h6></td>
			</table>
			
		</form>
</div>
	<script>
		window.print();
	</script>
</body>
</html>

<?php
	if(isset($_POST['checkout']))
	{
		$kode = implode(",", $_POST['kode']);
		$kode_plg = $_SESSION['pelanggan']['kode_plg'];
		$tgl_pesan = date("Y-m-d");
		$conn->query("INSERT INTO pesanan(kode_pesan,kode_plg,kode_brg,tgl_pesan) VALUES('','$kode_plg','$kode','$tgl_pesan')");

		echo "<script>alert('pesanan sukses');</script>";
		echo "<script>location='?page=checkout';</script>";
	}
?>