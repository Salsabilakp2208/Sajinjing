<?php
	//echo "<pre>";
	//print_r($_SESSION['keranjang']);
	//echo "</pre>";

	include "koneksi.php";

	if(empty($_SESSION['keranjang']) OR !isset($_SESSION['keranjang']))
	{
		echo "<script>alert('keranjang kosong, silahkan pilih tas custom Anda');</script>";	
		echo "<script>location='http://localhost/customgoodybag/portalPLG.php?page=custom';</script>";	
	}
?>

<html>
<head>
	<title>DATA PESAN</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>

<div align="center" >
	<center><h3>DATA PESANAN</h3></center>
		<table width="100% auto">
			<tr height="80" align="center" bgcolor="#4CAF50" >
				<td width="1%">NO</td>
				<td width="1%">ID</td>
				<td width="1%">JENIS GD</td>
				<td width="1%">NAMA GD</td>
				<td width="1%">DESC</td>
				<td width="1%">WARNA</td>
				<td width="1.5%">HARGA</td>
				<td width="1%">QTY</td>
				<td width="1%">SUBHARGA</td>
				<td width="1%">AKSI</td>
			</tr>

			<?php $no=1;?>
			<?php foreach ($_SESSION['keranjang'] as $kode_brg => $jumlah) : ?>
			<?php
				$ambil = $conn->query("SELECT *FROM barang WHERE kode_brg='$kode_brg' ");
				$pecah = $ambil ->fetch_assoc();
				
				$subharga = $pecah['harga']*$jumlah;
				//echo "<pre>";
				//print_r($pecah);
				//echo "</pre>";
			?>
			<tr align="center">
				<td><?php echo $no; ?></td>
				<td><?php echo $pecah['kode_brg']; ?></td>
				<td><?php echo $pecah['jenis_brg']; ?></td>
				<td><?php echo $pecah['nama']; ?></td>
				<td><?php echo $pecah['ukuran']; ?></td>
				<td><?php echo $pecah['warna']; ?></td>
				<td>Rp. <?php echo number_format($pecah['harga']); ?></td>
				<td><?php echo $jumlah; ?></td>
				<td>Rp. <?php echo number_format($subharga); ?></td>
				<td>
					<a href="hapuskeranjang.php?id=<?php echo $kode_brg?>"><button>Remove</button></a>
					
				</td>
			</tr>
			<?php $no++;?>
			<?php endforeach ?>
		</table>
		<br>
		<div class="btn-login">
			<a href="?page=custom">Lanjutkan pemesanan</a>
		</div>
</div>
</body>
</html>