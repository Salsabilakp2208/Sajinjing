<?php
	include "koneksi.php";
	$kode_custom = $_GET['id'];
	$query="DELETE FROM custom WHERE kode_custom='$kode_custom'";
	mysqli_query($conn,$query);

	echo "<script>alert('data berhasil dihapus');</script>";
	header("location:http://localhost/customgoodybag/portalPGW.php?page=pemesanan");
?>