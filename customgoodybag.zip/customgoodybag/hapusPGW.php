<?php
	include "koneksi.php";
	$kode_pgw = $_GET['id'];
	$query="DELETE FROM pegawai WHERE kode_pgw='$kode_pgw'";
	mysqli_query($conn,$query);

	echo "<script>alert('data berhasil dihapus');</script>";
	header("location:http://localhost/customgoodybag/portalPGW.php?page=pegawai");
?>