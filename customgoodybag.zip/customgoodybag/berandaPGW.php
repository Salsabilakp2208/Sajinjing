<link rel="stylesheet" type="text/css" href="tugas3.css">
<h1>SELAMAT DATANG ADMINISTRATOR</h1>
<h1><?php echo $_SESSION['pegawai']['nama_pgw']; ?></h1>

<div align="left">
<p>1. <button>DATA PEGAWAI</button>, Anda dapat melakukan edit, hapus dan searching.</p>
<p>2. <button>DATA PELANGGAN</button>, Anda dapat melakukan edit, hapus dan searching.</p>
<p>3. <button>DATA PESANAN</button>, Anda melihat riwayat belanja pelanggan serta status pesanannya</p>
</div>