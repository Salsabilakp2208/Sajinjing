<?php
	$server="localhost";
	$username="root";
	$password="";
	$conn=mysqli_connect($server,$username,$password,"customgoodybag") or die("tidak terkoneksi");
?>