<?php
	include "koneksi.php";
	$kode_plg = $_GET['id'];
	$query="DELETE FROM pelanggan WHERE kode_plg='$kode_plg'";
	mysqli_query($conn,$query);

	echo "<script>alert('data berhasil dihapus');</script>";
	header("location:http://localhost/customgoodybag/portalPGW.php?page=pelanggan");
?>