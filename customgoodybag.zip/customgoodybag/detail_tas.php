<?php
	include "koneksi.php";

	$kode_brg = $_GET['id'];
	$ambil = $conn->query("SELECT *FROM barang WHERE kode_brg='$kode_brg' ");
	$detail = $ambil->fetch_assoc();
?>

<html>
<head>
	<title>DETAIL PESANAN KAMU</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body align="center">
	<h3>DETAIL PESANAN KAMU</h3>
	<table align="center">
		<tr>
			<td>ID TAS</td>
			<td><?php echo $detail['kode_brg']; ?></td>
		</tr>
		<tr>
			<td>JENIS TAS</td>
			<td><?php echo $detail['jenis_brg']; ?></td>
		</tr>
		<tr>
			<td>NAMA BARANG</td>
			<td><?php echo $detail['nama']; ?></td>
		</tr>
		<tr>
			<td>UKURAN</td>
			<td><?php echo $detail['ukuran']; ?></td>
		</tr>
		<tr>
			<td>WARNA</td>
			<td><?php echo $detail['warna']; ?></td>
		</tr>
		<tr>
			<td>HARGA</td>
			<td><?php echo $detail['harga']; ?></td>
		</tr>
	</table>
	
		<form method="POST">
			<br>
			<p>Custom tas tidak boleh dari 5 item yang sama.</p>
			<input type="number" size="3" name="jumlah" min="1" max="<?php echo $detail['stok'] ?>">
			<button name="pesan">PESAN</button>
		</form>

		<?php
			if(isset($_POST['pesan']))
			{
				$jumlah = $_POST['jumlah'];
				$_SESSION['keranjang'][$kode_brg] = $jumlah;

				echo "<script>alert('pesanan telah ditambahkan');</script>";	
				echo "<script>location='http://localhost/customgoodybag/portalPLG.php?page=pesan';</script>";	
			}
		?>
</body>
</html>