<html>
<head>
	<title>HASIL PENCARIAN</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body width="100% auto">
	<center>
		<h3>HASIL PENCARIAN</h3>
	<table width="100% auto">
		<tr>
			<th colspan="8">DATA PEGAWAI</th>
		</tr>
		<tr height="40">
			<th>NO</th>
			<th>ID PEGAWAI</th>
			<th>PASSWORD</th>
			<th>NAMA PEGAWAI</th>
			<th>&emsp;JK&emsp;</th>
			<th>ALAMAT</th>
			<th>NO TELP/WA</th>
			<th>AKSI</th>
		</tr>
		
				<?php $no=1;?>
				<?php 
				include "koneksi.php";
				$no=1;
				$cari = $_POST['search'];
				$sql = "SELECT *FROM pegawai ";
				$pilih = mysqli_query($conn, "SELECT *FROM pegawai WHERE nama_pgw LIKE '%$cari%' ");
				while($data=mysqli_fetch_array($pilih)): ?>
				<tr>
					<td><center><?php echo $no++;?></center></td>
					<td><center><?php echo $data['kode_pgw'];?></center></td>
					<td><center><?php echo $data['password'];?></center></td>
					<td><center><?php echo $data['nama_pgw'];?></center></td>
					<td><center><?php echo $data['jenis_kelamin'];?></center></td>
					<td><center><?php echo $data['alamat'];?></center></td>
					<td><center><?php echo $data['no_telp'];?></center></td>
					<td>
						<a href="?page=editPGW&id=<?php echo $data['kode_pgw'];?>"><button> EDIT</button></a>
						<a href="hapusPGW.php?id=<?php echo $data['kode_pgw'];?>"><button>DELETE</button></a>
					</td>	
				</tr>
				<?php endwhile; ?>
	</table>
	<br><br><br>
	<a href="portalPGW.php?page=pegawai"><button>KEMBALI KE PENCARIAN</button></a>
	</center>
</body>
</html>