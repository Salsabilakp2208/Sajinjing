<html>
<head>
	<title>HASIL PENCARIAN</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body width="90% auto">
	<center>
		<h3>HASIL PENCARIAN</h3>
	<table cellpadding="0" cellspacing="0" width="800">
		<tr>
			<th colspan="8">DATA PELANGGAN</th>
		</tr>
		<tr height="40">
			<th>NO</th>
			<th>ID PELANGGAN</th>
			<th>PASSWORD</th>
			<th>NAMA PELANGGAN</th>
			<th>&emsp;JK&emsp;</th>
			<th>ALAMAT</th>
			<th>NO TELP/WA</th>
			<th>AKSI</th>
		</tr>
		
				<?php $no=1;?>
				<?php 
				include "koneksi.php";
				$no=1;
				$cari = $_POST['search'];
				$sql = "SELECT *FROM pelanggan ";
				$pilih = mysqli_query($conn, "SELECT *FROM pelanggan WHERE nama_plg LIKE '%$cari%' ");
				while($d=mysqli_fetch_array($pilih)): ?>
				<tr>
					<td><center><?php echo $no++;?></center></td>
					<td><center><?php echo $d['kode_plg'];?></center></td>
					<td><center><?php echo $d['password'];?></center></td>
					<td><center><?php echo $d['nama_plg'];?></center></td>
					<td><center><?php echo $d['jenis_kelamin'];?></center></td>
					<td><center><?php echo $d['alamat'];?></center></td>
					<td><center><?php echo $d['no_telp'];?></center></td>
					<td>
						<a href="?page=editPLG&id=<?php echo $d['kode_plg'];?>"><button> EDIT</button></a>
						<a href="hapusPLG.php?id=<?php echo $d['kode_plg'];?>"><button>DELETE</button></a>
					</td>
				</tr>
				<?php endwhile; ?>
	</table>
	<br><br><br>
	<a href="portalPGW.php?page=pelanggan"><button>KEMBALI KE PENCARIAN</button></a>
	</center>
</body>
</html>