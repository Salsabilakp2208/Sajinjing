<?php
	session_start();
	$kode_brg = $_GET['id'];

	if(isset($_SESSION['keranjang'][$kode_brg])){
		$_SESSION['keranjang'][$kode_brg] += 1;
	}
	else{
		$_SESSION['keranjang'][$kode_brg] = 1;
	}

	//echo "<pre>";
	//print_r($_SESSION);
	//echo "</pre>";

	//larikan ke halaman pesan
	echo "<script>alert('produk telah masuk ke keranjang belanja');</script>";	
	echo "<script>location='http://localhost/customgoodybag/portalPLG.php?page=pesan';</script>";	
?>