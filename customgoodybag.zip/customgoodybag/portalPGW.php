<?php
	session_start();
	include "koneksi.php";

	if(!isset($_SESSION['pegawai']))
	{
		echo "<script>alert('Anda harus login');</script>";
		echo "<script>location='login.php';</script>";
		header('location:login.php');
		exit();
	}
?>
<html>
<head>
	<title>WEBSITE CUSTOM GOODY BAG</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
<div id="header">
	<div class="menu-bar">
		<h1>CUSTOM GOODY BAG</h1>
	</div>
	<nav>
		<ul>
			<li><a href="portalPGW.php?page=beranda">BERANDA</a></li>
			<li><a href="portalPGW.php?page=pegawai">DATA PEGAWAI</a></li>
			<li><a href="portalPGW.php?page=pelanggan">DATA PELANGGAN</a></li>
			<li><a href="portalPGW.php?page=pemesanan">DATA PESANAN</a></li>	
			<li><a href="portalPGW.php?page=logout">LOGOUT</a></li>
		</ul>	
	</nav>
</div>


		<div class="konten">
			<?php
			if(isset($_GET['page'])){
					if($_GET['page']=="logout")
					{
						include "logout.php";
					}
					elseif ($_GET['page']=="pegawai") {
						include "dataPegawai.php";
					}
					elseif ($_GET['page']=="pelanggan") {
						include "dataPelanggan.php";
					}
					elseif ($_GET['page']=="pemesanan") {
						include "pemesanan.php";
					}
					elseif ($_GET['page']=="editPGW") {
						include "editPGW.php";
					}
					elseif ($_GET['page']=="editPLG") {
						include "editPLG.php";
					}
					elseif ($_GET['page']=="cari") {
						include "cari.php";
					}
					elseif ($_GET['page']=="cari2") {
						include "cari2.php";
					}
					elseif ($_GET['page']=="cariCS") {
						include "cariCS.php";
					}
					elseif ($_GET['page']=="beranda") {
						include "berandaPGW.php";
					}
					else
					{
						include "berandaPGW.php";
					}
			}
			?>
		</div>		
</body>
</html>
