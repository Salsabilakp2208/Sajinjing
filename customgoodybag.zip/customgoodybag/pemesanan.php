<?php
	include "koneksi.php";
?>
<html>
<head>
	<title>DATA PESANAN</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
		<form method="POST" action="?page=cariCS">
			<input type="text" name="search" placeholder="Value To Search">
			<input type="submit" name="submit" value="FILTER">
			<br><br>
		</form>

	<center>
	<table width="100% auto">
		<tr>
			<th colspan="8">DATA PESANAN</th>
		</tr>
		<tr height="40">
			<th>NO</th>
			<th>KODE CUSTOM</th>
			<th>KODE BARANG</th>
			<th>KODE PEGAWAI</th>
			<th>TARIF</th>
			<th>BUKTI BAYAR</th>
			<th>AKSI</th>
		</tr>
		
				<?php $no=1;?>
				<?php 
				$sql = "SELECT *FROM custom ";
				$query = mysqli_query($conn, $sql);
				while($data=mysqli_fetch_array($query)): ?>
				<tr>
					<td><center><?php echo $no++;?></center></td>
					<td><center><?php echo $data['kode_custom'];?></center></td>
					<td><center><?php echo $data['kode_brg'];?></center></td>
					<td><center><?php echo $data['kode_pgw'];?></center></td>
					<td><center><?php echo $data['tarif'];?></center></td>
					<td><center> <?php echo "<img src='buktipembayaran/".$data['bayar']."' width='700px' height='300px' alt='bukti transfer' >";?></center></td>
					<td align="center">
						<a href="hapusCS.php?id=<?php echo $data['kode_custom'];?>"><button>REMOVE</button></a>
					</td>	
				</tr>
		<?php endwhile; ?>

	</table>
	</center>
</body>
</html>

