<?php
	session_start();
	include "koneksi.php";

	if(!isset($_SESSION['pelanggan']))
	{
		echo "<script>alert('Anda harus login');</script>";
		echo "<script>location='login2.php';</script>";
		header('location:login2.php');
		exit();
	}
?>
<html>
<head>
	<title>WEBSITE CUSTOM GOODY BAG</title>
	<link rel="stylesheet" type="text/css" href="tugas3.css">
</head>
<body>
<div id="header">
	<div class="menu-bar">
		<h1>CUSTOM GOODY BAG</h1>
	</div>
	
	<nav>
		<ul>
			<li><a href="portalPLG.php?page=beranda">BERANDA</a></li>
			<li><a href="portalPLG.php?page=custom">LIST TAS CUSTOM</a></li>
			<li><a href="portalPLG.php?page=pesan">PESANAN</a></li>
			<li><a href="portalPLG.php?page=checkout">CHECKOUT</a></li>
			<li><a href="portalPLG.php?page=nota">NOTA</a></li>
			<li><a href="portalPLG.php?page=logout">LOGOUT</a></li>
		</ul>
	</nav>
</div>	

		<div class="konten">
			<?php
			if(isset($_GET['page'])){
					if($_GET['page']=="logout")
					{
						include "logout2.php";
					}
					elseif ($_GET['page']=="custom") {
						include "dataBarang.php";
					}
					elseif ($_GET['page']=="pesan") {
						include "dataPesan.php";
					}
					elseif ($_GET['page']=="checkout") {
						include "checkout.php";
					}
					elseif ($_GET['page']=="detail") {
						include "detail_tas.php";
					}
					elseif ($_GET['page']=="beranda")
					{
						include "berandaPLG.php";
					}
					elseif ($_GET['page']=="nota")
					{
						include "dataCustom.php";
					}
					else
					{
						include "berandaPLG.php";
					}
			}
		?>
		</div>		
</body>
</html>
